import "package:flutter/material.dart";

class MaterialTheme {
  final TextTheme textTheme;

  const MaterialTheme(this.textTheme);

  static ColorScheme lightScheme() {
    return const ColorScheme(
      brightness: Brightness.light,
      primary: Color(4289462429),
      surfaceTint: Color(4289462429),
      onPrimary: Color(4294967295),
      primaryContainer: Color(4294926822),
      onPrimaryContainer: Color(4281204777),
      secondary: Color(4288426636),
      onSecondary: Color(4294967295),
      secondaryContainer: Color(4294940135),
      onSecondaryContainer: Color(4283891790),
      tertiary: Color(4289931559),
      onTertiary: Color(4294967295),
      tertiaryContainer: Color(4294932333),
      onTertiaryContainer: Color(4281663490),
      error: Color(4290386458),
      onError: Color(4294967295),
      errorContainer: Color(4294957782),
      onErrorContainer: Color(4282449922),
      surface: Color(4294965241),
      onSurface: Color(4280620833),
      onSurfaceVariant: Color(4283842639),
      outline: Color(4287197312),
      outlineVariant: Color(4292656849),
      shadow: Color(4278190080),
      scrim: Color(4278190080),
      inverseSurface: Color(4282068022),
      inversePrimary: Color(4294946025),
      primaryFixed: Color(4294957041),
      onPrimaryFixed: Color(4281925683),
      primaryFixedDim: Color(4294946025),
      onPrimaryFixedVariant: Color(4286840951),
      secondaryFixed: Color(4294957041),
      onSecondaryFixed: Color(4281925683),
      secondaryFixedDim: Color(4294946025),
      onSecondaryFixedVariant: Color(4286518642),
      tertiaryFixed: Color(4294957782),
      onTertiaryFixed: Color(4282449923),
      tertiaryFixedDim: Color(4294948012),
      onTertiaryFixedVariant: Color(4287630098),
      surfaceDim: Color(4293645537),
      surfaceBright: Color(4294965241),
      surfaceContainerLowest: Color(4294967295),
      surfaceContainerLow: Color(4294963447),
      surfaceContainer: Color(4294961397),
      surfaceContainerHigh: Color(4294632175),
      surfaceContainerHighest: Color(4294237418),
    );
  }

  ThemeData light() {
    return theme(lightScheme());
  }

  static ColorScheme lightMediumContrastScheme() {
    return const ColorScheme(
      brightness: Brightness.light,
      primary: Color(4286382193),
      surfaceTint: Color(4289462429),
      onPrimary: Color(4294967295),
      primaryContainer: Color(4292018368),
      onPrimaryContainer: Color(4294967295),
      secondary: Color(4286189166),
      onSecondary: Color(4294967295),
      secondaryContainer: Color(4290202276),
      onSecondaryContainer: Color(4294967295),
      tertiary: Color(4287235087),
      onTertiary: Color(4294967295),
      tertiaryContainer: Color(4291968826),
      onTertiaryContainer: Color(4294967295),
      error: Color(4287365129),
      onError: Color(4294967295),
      errorContainer: Color(4292490286),
      onErrorContainer: Color(4294967295),
      surface: Color(4294965241),
      onSurface: Color(4280620833),
      onSurfaceVariant: Color(4283579467),
      outline: Color(4285552744),
      outlineVariant: Color(4287460228),
      shadow: Color(4278190080),
      scrim: Color(4278190080),
      inverseSurface: Color(4282068022),
      inversePrimary: Color(4294946025),
      primaryFixed: Color(4292018368),
      onPrimaryFixed: Color(4294967295),
      primaryFixedDim: Color(4289200281),
      onPrimaryFixedVariant: Color(4294967295),
      secondaryFixed: Color(4290202276),
      onSecondaryFixed: Color(4294967295),
      secondaryFixedDim: Color(4288229257),
      onSecondaryFixedVariant: Color(4294967295),
      tertiaryFixed: Color(4291968826),
      onTertiaryFixed: Color(4294967295),
      tertiaryFixedDim: Color(4289668645),
      onTertiaryFixedVariant: Color(4294967295),
      surfaceDim: Color(4293645537),
      surfaceBright: Color(4294965241),
      surfaceContainerLowest: Color(4294967295),
      surfaceContainerLow: Color(4294963447),
      surfaceContainer: Color(4294961397),
      surfaceContainerHigh: Color(4294632175),
      surfaceContainerHighest: Color(4294237418),
    );
  }

  ThemeData lightMediumContrast() {
    return theme(lightMediumContrastScheme());
  }

  static ColorScheme lightHighContrastScheme() {
    return const ColorScheme(
      brightness: Brightness.light,
      primary: Color(4282712126),
      surfaceTint: Color(4289462429),
      onPrimary: Color(4294967295),
      primaryContainer: Color(4286382193),
      onPrimaryContainer: Color(4294967295),
      secondary: Color(4282712126),
      onSecondary: Color(4294967295),
      secondaryContainer: Color(4286189166),
      onSecondaryContainer: Color(4294967295),
      tertiary: Color(4283301892),
      onTertiary: Color(4294967295),
      tertiaryContainer: Color(4287235087),
      onTertiaryContainer: Color(4294967295),
      error: Color(4283301890),
      onError: Color(4294967295),
      errorContainer: Color(4287365129),
      onErrorContainer: Color(4294967295),
      surface: Color(4294965241),
      onSurface: Color(4278190080),
      onSurfaceVariant: Color(4281409068),
      outline: Color(4283579467),
      outlineVariant: Color(4283579467),
      shadow: Color(4278190080),
      scrim: Color(4278190080),
      inverseSurface: Color(4282068022),
      inversePrimary: Color(4294960628),
      primaryFixed: Color(4286382193),
      onPrimaryFixed: Color(4294967295),
      primaryFixedDim: Color(4283891790),
      onPrimaryFixedVariant: Color(4294967295),
      secondaryFixed: Color(4286189166),
      onSecondaryFixed: Color(4294967295),
      secondaryFixedDim: Color(4283891790),
      onSecondaryFixedVariant: Color(4294967295),
      tertiaryFixed: Color(4287235087),
      onTertiaryFixed: Color(4294967295),
      tertiaryFixedDim: Color(4284547078),
      onTertiaryFixedVariant: Color(4294967295),
      surfaceDim: Color(4293645537),
      surfaceBright: Color(4294965241),
      surfaceContainerLowest: Color(4294967295),
      surfaceContainerLow: Color(4294963447),
      surfaceContainer: Color(4294961397),
      surfaceContainerHigh: Color(4294632175),
      surfaceContainerHighest: Color(4294237418),
    );
  }

  ThemeData lightHighContrast() {
    return theme(lightHighContrastScheme());
  }

  static ColorScheme darkScheme() {
    return const ColorScheme(
      brightness: Brightness.dark,
      primary: Color(4294946025),
      surfaceTint: Color(4294946025),
      onPrimary: Color(4284285012),
      primaryContainer: Color(4292018368),
      onPrimaryContainer: Color(4294967295),
      secondary: Color(4294946025),
      onSecondary: Color(4284285012),
      secondaryContainer: Color(4285991275),
      onSecondaryContainer: Color(4294952173),
      tertiary: Color(4294948012),
      onTertiary: Color(4285071367),
      tertiaryContainer: Color(4291968826),
      onTertiaryContainer: Color(4294967295),
      error: Color(4294948011),
      onError: Color(4285071365),
      errorContainer: Color(4287823882),
      onErrorContainer: Color(4294957782),
      surface: Color(4280028952),
      onSurface: Color(4294237418),
      onSurfaceVariant: Color(4292656849),
      outline: Color(4288973210),
      outlineVariant: Color(4283842639),
      shadow: Color(4278190080),
      scrim: Color(4278190080),
      inverseSurface: Color(4294237418),
      inversePrimary: Color(4289462429),
      primaryFixed: Color(4294957041),
      onPrimaryFixed: Color(4281925683),
      primaryFixedDim: Color(4294946025),
      onPrimaryFixedVariant: Color(4286840951),
      secondaryFixed: Color(4294957041),
      onSecondaryFixed: Color(4281925683),
      secondaryFixedDim: Color(4294946025),
      onSecondaryFixedVariant: Color(4286518642),
      tertiaryFixed: Color(4294957782),
      onTertiaryFixed: Color(4282449923),
      tertiaryFixedDim: Color(4294948012),
      onTertiaryFixedVariant: Color(4287630098),
      surfaceDim: Color(4280028952),
      surfaceBright: Color(4282660159),
      surfaceContainerLowest: Color(4279634451),
      surfaceContainerLow: Color(4280620833),
      surfaceContainer: Color(4280884005),
      surfaceContainerHigh: Color(4281607728),
      surfaceContainerHighest: Color(4282331194),
    );
  }

  ThemeData dark() {
    return theme(darkScheme());
  }

  static ColorScheme darkMediumContrastScheme() {
    return const ColorScheme(
      brightness: Brightness.dark,
      primary: Color(4294947818),
      surfaceTint: Color(4294946025),
      onPrimary: Color(4281335851),
      primaryContainer: Color(4294522593),
      onPrimaryContainer: Color(4278190080),
      secondary: Color(4294947818),
      onSecondary: Color(4281335851),
      secondaryContainer: Color(4292372419),
      onSecondaryContainer: Color(4278190080),
      tertiary: Color(4294949554),
      onTertiary: Color(4281794562),
      tertiaryContainer: Color(4294466387),
      onTertiaryContainer: Color(4278190080),
      error: Color(4294949553),
      onError: Color(4281794561),
      errorContainer: Color(4294923337),
      onErrorContainer: Color(4278190080),
      surface: Color(4280028952),
      onSurface: Color(4294965753),
      onSurfaceVariant: Color(4292920021),
      outline: Color(4290223021),
      outlineVariant: Color(4287986829),
      shadow: Color(4278190080),
      scrim: Color(4278190080),
      inverseSurface: Color(4294237418),
      inversePrimary: Color(4286972025),
      primaryFixed: Color(4294957041),
      onPrimaryFixed: Color(4280811555),
      primaryFixedDim: Color(4294946025),
      onPrimaryFixedVariant: Color(4284940381),
      secondaryFixed: Color(4294957041),
      onSecondaryFixed: Color(4280811555),
      secondaryFixedDim: Color(4294946025),
      onSecondaryFixedVariant: Color(4284940381),
      tertiaryFixed: Color(4294957782),
      onTertiaryFixed: Color(4281139201),
      tertiaryFixedDim: Color(4294948012),
      onTertiaryFixedVariant: Color(4285726729),
      surfaceDim: Color(4280028952),
      surfaceBright: Color(4282660159),
      surfaceContainerLowest: Color(4279634451),
      surfaceContainerLow: Color(4280620833),
      surfaceContainer: Color(4280884005),
      surfaceContainerHigh: Color(4281607728),
      surfaceContainerHighest: Color(4282331194),
    );
  }

  ThemeData darkMediumContrast() {
    return theme(darkMediumContrastScheme());
  }

  static ColorScheme darkHighContrastScheme() {
    return const ColorScheme(
      brightness: Brightness.dark,
      primary: Color(4294965753),
      surfaceTint: Color(4294946025),
      onPrimary: Color(4278190080),
      primaryContainer: Color(4294947818),
      onPrimaryContainer: Color(4278190080),
      secondary: Color(4294965753),
      onSecondary: Color(4278190080),
      secondaryContainer: Color(4294947818),
      onSecondaryContainer: Color(4278190080),
      tertiary: Color(4294965753),
      onTertiary: Color(4278190080),
      tertiaryContainer: Color(4294949554),
      onTertiaryContainer: Color(4278190080),
      error: Color(4294965753),
      onError: Color(4278190080),
      errorContainer: Color(4294949553),
      onErrorContainer: Color(4278190080),
      surface: Color(4280028952),
      onSurface: Color(4294967295),
      onSurfaceVariant: Color(4294965753),
      outline: Color(4292920021),
      outlineVariant: Color(4292920021),
      shadow: Color(4278190080),
      scrim: Color(4278190080),
      inverseSurface: Color(4294237418),
      inversePrimary: Color(4283564106),
      primaryFixed: Color(4294958578),
      onPrimaryFixed: Color(4278190080),
      primaryFixedDim: Color(4294947818),
      onPrimaryFixedVariant: Color(4281335851),
      secondaryFixed: Color(4294958578),
      onSecondaryFixed: Color(4278190080),
      secondaryFixedDim: Color(4294947818),
      onSecondaryFixedVariant: Color(4281335851),
      tertiaryFixed: Color(4294959324),
      onTertiaryFixed: Color(4278190080),
      tertiaryFixedDim: Color(4294949554),
      onTertiaryFixedVariant: Color(4281794562),
      surfaceDim: Color(4280028952),
      surfaceBright: Color(4282660159),
      surfaceContainerLowest: Color(4279634451),
      surfaceContainerLow: Color(4280620833),
      surfaceContainer: Color(4280884005),
      surfaceContainerHigh: Color(4281607728),
      surfaceContainerHighest: Color(4282331194),
    );
  }

  ThemeData darkHighContrast() {
    return theme(darkHighContrastScheme());
  }


  ThemeData theme(ColorScheme colorScheme) => ThemeData(
     useMaterial3: true,
     brightness: colorScheme.brightness,
     colorScheme: colorScheme,
     textTheme: textTheme.apply(
       bodyColor: colorScheme.onSurface,
       displayColor: colorScheme.onSurface,
     ),
     scaffoldBackgroundColor: colorScheme.background,
     canvasColor: colorScheme.surface,
  );


  List<ExtendedColor> get extendedColors => [
  ];
}

class ExtendedColor {
  final Color seed, value;
  final ColorFamily light;
  final ColorFamily lightHighContrast;
  final ColorFamily lightMediumContrast;
  final ColorFamily dark;
  final ColorFamily darkHighContrast;
  final ColorFamily darkMediumContrast;

  const ExtendedColor({
    required this.seed,
    required this.value,
    required this.light,
    required this.lightHighContrast,
    required this.lightMediumContrast,
    required this.dark,
    required this.darkHighContrast,
    required this.darkMediumContrast,
  });
}

class ColorFamily {
  const ColorFamily({
    required this.color,
    required this.onColor,
    required this.colorContainer,
    required this.onColorContainer,
  });

  final Color color;
  final Color onColor;
  final Color colorContainer;
  final Color onColorContainer;
}
